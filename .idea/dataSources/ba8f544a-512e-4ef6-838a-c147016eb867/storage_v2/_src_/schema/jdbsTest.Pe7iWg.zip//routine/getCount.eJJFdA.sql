create procedure getCount()
begin
  select count(*) from Users;
  select count(*) from Books;
end;

