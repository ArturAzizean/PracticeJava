create procedure BooksCount(OUT cnt int)
begin
  select count(*) into cnt from Books;
end;

