create procedure getBooks(IN bookId int)
begin
  select * from Books where id = bookId;
end;

